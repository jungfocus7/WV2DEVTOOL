import http from "node:http";


const userData = JSON.stringify({
    email: 'pook61@ppop.pe.kr',
    name: '박종식',
    age: 37,
});

/** @type {http.ClientRequestArgs} */
const options = {
    hostname: 'localhost',
    port: 3000,
    method: 'POST',
    path: '/',
    headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(userData)
    }
};

const req = http.request(options, (res) => {
    console.log(`STATUS: ${res.statusCode}`);
    console.log(`HEADERS: ${JSON.stringify(res.headers, null, 2)}`);

    let resultBuffer = [];

    // 1. 데이터 수신 (청크 단위)
    res.on('data', (chunk) => {
        // resultBuffer += chunk;
        // console.log(resultBuffer);
        resultBuffer.push(chunk.toString());
    });

    // 2. 데이터 수신 완료
    res.on('end', () => {
        try {
            const parsedData = JSON.parse(resultBuffer.join(''));
            console.log('Response data:', JSON.stringify(parsedData, null, 2));
        } catch (err) {
            console.error('JSON parsing error:', err.message);
        }
    });
});

// 3. 요청 중 오류 처리
req.on('error', (e) => {
    console.error(`문제 발생: ${e.message}`);
});

// 4. 요청 본문 작성
req.write(userData);

// 5. 요청 전송 완료 (필수)
req.end();