import {  } from "Request";


console.log('시작~~~~~~');

let _num = 369;
switch (_num) {
    case '369':
        console.log('문자열 346');
        break;

    case 369:
        console.log('숫자 346');
        break;

    default:
        console.log('아무코토');
        break;
}

if (_num == '369') {
    console.log(1);
} else if (_num === 369) {
    console.log(2);
} else if (_num == 369) {
    console.log(3);
}