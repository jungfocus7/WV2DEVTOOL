import http from "node:http";



//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
const _METHODS = {
    POST: 'POST',
    GET: 'GET',
};

const _EVENTS = {
    DATA: 'data',
    END: 'end',
};

const _PORT = 3000;


/**
 * @param {http.IncomingMessage} req
 * @param {http.ServerResponse} res
 */
const fn_reqPostEnd = (req, res) => {
    let arr = [];

    req.on('data', (chunk) => {
        console.log('fn_reqOnData >>>');

        arr.push(chunk.toString());
    });

    req.on('end', () => {
        console.log('fn_reqOnEnd >>>');

        let ro = null;
        try {
            let rs = arr.join('');
            console.log('>>>', rs);
            ro = JSON.parse(rs);
        } catch (err) {
        }

        res.writeHead(200, {'Content-Type': 'application/json'});
        res.end(JSON.stringify({
            state: 'success',
            data: {
                email: ro.email,
                authKey: 'DK!@#)AD$K!@#~KDA',
            },
        }, null, 2));
    });
};

/**
 * Request Callback Function
 * @param {http.IncomingMessage} req
 * @param {http.ServerResponse} res
 */
const fn_reqcbf = (req, res) => {
    if (req.method === _METHODS.POST) {
        console.log('POST >>>');
        fn_reqPostEnd(req, res);
    } else {
        res.writeHead(200, {'Content-Type': 'application/json'});
        res.end(JSON.stringify({
            state: 'error',
            data: '',
        }, null, 2));
    }
};


const _server = http.createServer(fn_reqcbf);

_server.listen(_PORT, () => {
    console.log(`Server running at http://localhost:${_PORT}/`);
});





//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
const fn_getText = async (url) => {
    try {
        const res = await fetch(url, {
            method: 'POST',
            body: '0123456789',
        });

        if (!res.ok) {
            throw `HTTP error, status = ${res.status}`;
        }

        const txt = await res.text();
        console.log(txt);
        return txt;

    } catch (err) {
        console.error(`Error: ${err.message}`);
    }
};
// fn_getText('http://localhost:3000/');