'use strict';
const fs = require('node:fs');
const path = require('node:path');
const readline = require('node:readline');



/**
 * 한줄 주석 여부
 * @param {string} ts (trim str)
 * @returns boolean
 */
const fn_checkComments = (ts) => {
    const rex = /^[ \t]*\/\/[^\r\n]*$/;
    return rex.test(ts);
};


/**
 * 레기온 주석 여부
 * @param {string} ts (trim str)
 * @returns boolean
 */
const fn_checkRegion = (ts) => {
    return ts.startsWith('//#region ') || ts.startsWith('//#endregion ');
};


/**
 * 에프터 기타 주석 제거
 * @param {string} rstr
 * @returns string
 */
const fn_afterClearComments = (rstr) => {
    const rex = /\/\*[^\*\/]*\*\//gm;
    return rstr.replaceAll(rex, '');
};


const _rlst = [];


/**
 * 핵심 작업
 * @param {string} ip input
 * @param {string} op output
 */
const fn_work = async (ip, op) => {
    try {
        const ifp = ip;
        fs.accessSync(ifp);
        const ofp = op;

        const rl = readline.createInterface({
            input: fs.createReadStream(ifp),
            crlfDelay: Infinity,
        });

        for await (const ls of rl) {
            if (ls === '') continue;
            const ts = ls.trim();
            if (fn_checkComments(ts) || fn_checkRegion(ts)) {
                // console.log('pass', ts);
            }
            else {
                lst.push(ls.trim());
            }
        }

        if (lst.length > 0) {
            const rstr = fn_afterClearComments(lst.join('\n'));
            // console.log(rstr);
            fs.writeFileSync(ofp, rstr, {encoding: 'utf8'});
        }
    }
    catch (e) {
        console.log(`# Error  ${e}`);
    }
};


const fn_entry = (ta) => {
    const ipa = ta;
    for (const ip of ipa) {
        const fnm = path.basename(ip);
        const di = fnm.lastIndexOf('.js');
        const op = path.resolve(__dirname, `../js/${fnm.substring(0, di)}.dist.js`);
        // console.log(ip, op);
        fn_work(ip, op);
    }
}


const ipa = [
    path.resolve(__dirname, 'hfCommon.js'),
    path.resolve(__dirname, 'hfCountTask.js'),
    path.resolve(__dirname, 'hfTween.js'),
    path.resolve(__dirname, 'hfWeich.js'),
];
fn_entry(ipa);






























// 'use strict';
// const fs = require('node:fs');
// const path = require('node:path');
// const readline = require('node:readline');


// const hxp = Object.freeze({

//     /**
//      * 한줄 주석 여부
//      * @param {string} ts (trim str)
//      * @returns boolean
//      */
//     fn_checkComments: (ts) => {
//         const rex = /^[ \t]*\/\/[^\r\n]*$/;
//         return rex.test(ts);
//     },

//     /**
//      * 레기온 주석 여부
//      * @param {string} ts (trim str)
//      * @returns boolean
//      */
//     fn_checkRegion: (ts) => {
//         return ts.startsWith('//#region ') || ts.startsWith('//#endregion ');
//     },

//     /**
//      * 에프터 기타 주석 제거
//      * @param {string} rstr
//      * @returns string
//      */
//     fn_afterClearComments: (rstr) => {
//         const rex = /\/\*[^\*\/]*\*\//gm;
//         return rstr.replaceAll(rex, '');
//     },

//     /**
//      * 핵심 작업
//      * @param {string} ip input
//      * @param {string} op output
//      */
//     fn_work: async (ip, op) => {
//         try {
//             const ifp = ip;
//             fs.accessSync(ifp);
//             const ofp = op;

//             const rl = readline.createInterface({
//                 input: fs.createReadStream(ifp),
//                 crlfDelay: Infinity,
//             });

//             const lst = [];
//             for await (const ls of rl) {
//                 if (ls === '') continue;
//                 const ts = ls.trim();
//                 if (hxp.fn_checkComments(ts) || hxp.fn_checkRegion(ts)) {
//                     // console.log('pass', ts);
//                 }
//                 else {
//                     lst.push(ls.trim());
//                 }
//             }

//             if (lst.length > 0) {
//                 const rstr = hxp.fn_afterClearComments(lst.join('\n'));
//                 // console.log(rstr);
//                 fs.writeFileSync(ofp, rstr, {encoding: 'utf8'});
//             }
//         }
//         catch (e) {
//             console.log(`# Error  ${e}`);
//         }
//     },


//     fn_entry: () => {

//     }
// });


// const ip = path.resolve(__dirname, 'hfCommon.js');
// const op = path.resolve(__dirname, '../js/hfCommon.dist.js');
// hxp.fn_work(ip, op);












// (async () => {
//     try {
//         const ifp = path.resolve(__dirname, 'test1.js');
//         fs.accessSync(ifp);

//         const rl = readline.createInterface({
//             input: fs.createReadStream(ifp),
//             crlfDelay: Infinity,
//         });

//         const rex = /^[ \t]*\/\/[^\r\n]*$/;
//         // const arr = [];
//         for await (const ls of rl) {
//             // console.log(`Line from file: ${ls}`);
//             if (rex.test(ls) === true) {
//                 console.log(ls);
//             }
//         }
//     }
//     catch (e) {}

//     console.log('# End of all.');
// })();










// const terser = require('terser');


// (async () => {
//     const code = `
// //#region \`hfTween: 트윈 클래스\`
// //https://github.com/jungfocus7/jhb0b_as3_libs/blob/master/hbx/src/hbx/balence/CSmoothControl.as
// export class hfWeich extends EventTarget {
//     static ET_UPDATE = 'update';
//     static ET_END = 'end';

//     constructor(now, speed = 0.3) {
//         super();
//         this.#running = false;
//         this.#end = now;
//         this.#now = now;
//         this.#speed = speed;
//         Object.seal(this);
//     }

//     #running = false;
//     get Running() {
//         return this.#running;
//     }

//     #end = 0.0;
//     get End() {
//         return this.#end;
//     }

//     #now = 0.0;
//     get Now() {
//         return this.#now;
//     }

//     #speed = 0.0;
//     get Speed() {
//         return this.#speed;
//     }


//     #fid = -1;
//     #ClearFrame = () => {
//         if (this.#fid === -1) return;
//         cancelAnimationFrame(this.#fid);
//         this.#fid = -1;
//     }
//     #LoopFrame = (t) => {
//         if (this.#running === false) return;
//         const dst = this.#end - this.#now;
//         if (Math.abs(dst) < 1) {
//             this.#now = this.#end;
//             this.dispatchEvent(new Event(hfWeich.ET_END));
//             this.Stop();
//         }
//         else {
//             this.#now = this.#now + (dst * this.#speed);
//             this.dispatchEvent(new Event(hfWeich.ET_UPDATE));
//         }
//         this.#fid = requestAnimationFrame(this.#LoopFrame);
//     }


//     Stop() {
//         if (this.#running === true) {
//             this.#ClearFrame();
//             this.#running = false;
//         }
//     }

//     FromTo(end, now, speed = NaN) {
//         if (this.#running === true)
//             this.Stop();
//         this.#end = end;
//         this.#now = now;
//         if (isNaN(speed) === false)
//             this.#speed = speed;
//         this.#running = true;
//         this.#fid = requestAnimationFrame(this.#LoopFrame);
//     }

//     To(end, speed = NaN) {
//         this.FromTo(end, this.#now, speed);
//     }
// }
// //#endregion`.trim();
//     // const res = await terser.minify(code, {format: {quote_style: 1, comments: false}});

//     console.log('# end all.');


// })();


